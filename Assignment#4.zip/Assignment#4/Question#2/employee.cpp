#include "employee.h"
employee::employee(int id1,int year1)
{
    id=id1;
    firstname="";
    lastname="";
    birth="";
    address="";
    yearhired=year1;
    salary=0.0;
    areacode=0;
    telephone="";
}
int employee::returnid()
{
    return id;
}
string employee::returnfirstname()
{
    return firstname;
}
void employee::modifyfirstname(string firstname1)
{
    firstname=firstname1;
}
string employee::returnlastname()
{
    return lastname;
}
void employee::modifylastname(string lastname1)
{
    lastname=lastname1;
}
int employee::returnyearhired()
{
    return yearhired;
}
string employee::returnfullname()
{
    string fullname=firstname+lastname;
    return fullname;
}
string employee::returnbirth()
{
    return birth;
}
void employee::modifybirth(string birth1)
{
    birth=birth1;
}
double employee::returnsalary()
{
    return salary;
}
void employee::modifysalary(double salary1)
{
    salary=salary1;
}
string employee::returnaddress()
{
    return address;
}
void employee::modifyaddress(string address1)
{
    address=address1;
}
string employee::returntelephone()
{
    return telephone;
}
int employee::returnareacode()
{
    return areacode;
}
void employee::modifytelephone(string telephone1)
{
    telephone=telephone1;
}
void employee::modifyareacode(int areacode1)
{
    areacode=areacode1;
}
bool employee::samelastname(string lastname1)
{
    if(lastname==lastname1)
        return true;
    else
        return false;
}
bool employee::samesalaryyear(double salary1,int yearhired1)
{
    if(salary==salary1||yearhired==yearhired1)
        return true;
    else
        return false;
}